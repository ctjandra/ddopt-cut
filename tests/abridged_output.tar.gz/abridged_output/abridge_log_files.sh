#!/bin/bash

# Script to reduce log file size and keep only the lines that are parsed by scripts (necessary lines are hardcoded)

if [ -z "$1" ]; then
        echo "Error: Input and output path not supplied"
        echo "Usage: ./abridge_log_files.sh INPUT_PATH OUTPUT_PATH"
        exit 1
fi

if [ -z "$2" ]; then
        echo "Error: Output path not supplied"
        echo "Usage: ./abridge_log_files.sh INPUT_PATH OUTPUT_PATH"
        exit 1
fi

mkdir $2

for f in $1/*.log; do
	grep -e "[-] width" -e "Number of nodes" -e "User cuts applied:" -e "CPLEX obj" -e "Time to .* BDD:" -e "Total (root" -e "Time to generate cut" -e "      0     0" -e "      0     2" -e "User:" -e "Feasible solutions" -e "Root node processing" -e "Sequential" -e "Real time" $f > "$2/`basename $f | cut -d. -f1`.abr"
done
